/*
 * if分支演示
 * */
#include <stdio.h>
int main() {
    int val = 0;
    printf("请输入一个整数：");
    scanf("%d", &val);
    if (val < 0) {
        printf("负数\n");
    }
    else if (val % 2) {
        printf("奇数\n");
    }
    else if (!(val % 2)) {
        printf("偶数\n");
    }
    return 0;
}




