/*
 * 逻辑表达式演示
 * */
#include <stdio.h>
int main() {
    int year = 0, ret = 0;
    printf("请输入年份数字：");
    scanf("%d", &year);
    ret = (!(year % 4) && (year % 100)) || !(year % 400);
    printf("结果是%d\n", ret);
    return 0;
}





