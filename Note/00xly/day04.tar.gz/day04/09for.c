/*
 * for循环练习
 * */
#include <stdio.h>
int main() {
    int num = 0, val = 10;
    for (num = 1;num <= 5;num++) {
        printf("%d X %d = %d\n", num, val - num, num * (val - num));
    }
    return 0;
}



