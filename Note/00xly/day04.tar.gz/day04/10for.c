/*
 * for循环练习
 * */
#include <stdio.h>
int main() {
    int min = 0, max = 0, tmp = 0;
    int num = 0, sum = 0;
    printf("请输入两个数字：");
    scanf("%d%d", &min, &max);
    if (min > max) {
        tmp = min;
        min = max;
        max = tmp;
    }
    for (num = min;num <= max;num++) {
        sum = sum + num;
    }
    printf("求和结果是%d\n", sum);
    return 0;
}





