/*
 * if分支演示
 * */
#include <stdio.h>
int main() {
    int val = 0;
    printf("请输入一个数字：");
    scanf("%d", &val);
    /*if (val >= 0) {
        printf("非负数\n");
    }
    else {
        printf("负数\n");
    }*/
    if (val > 0) {
        printf("正数\n");
    }
    else if (val < 0) {
        printf("负数\n");
    }
    else {
        printf("零\n");
    }
    return 0;
}





