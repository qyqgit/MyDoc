/*
 * for循环演示
 * */
#include <stdio.h>
int main() {
    int num = 0;
    for (num = 1;num <= 5;num++) {
        printf("%d ", num);
    }
    printf("\n");
    return 0;
}




