/*
 * 操作符演示
 * */
#include <stdio.h>
int main() {
    printf("!8是%d\n", !8);
    printf("3 < 7 < 5是%d\n", 3 < 7 < 5);
    printf("3 < 7 && 7 < 5是%d\n", 3 < 7 && 7 < 5);
    return 0;
}





