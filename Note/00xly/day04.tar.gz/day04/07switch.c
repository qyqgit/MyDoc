/*
 * 分支练习
 * */
#include <stdio.h>
int main() {
    int year = 0, month = 0;
    printf("请输入年份和月份：");
    scanf("%d%d", &year, &month);
    switch (month) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            printf("一共有31天\n");
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            printf("一共有30天\n");
            break;
        case 2:
            if ((!(year % 4) && (year % 100)) || !(year % 400)) {
                printf("一共有29天\n");
            }
            else {
                printf("一共有28天\n");
            }
            break;
        default:
            printf("错误的月份数字\n");
            break;
    }
    return 0;
}





