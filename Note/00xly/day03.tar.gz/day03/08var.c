/*
 * 变量练习
 * */
#include <stdio.h>
int main() {
    int val = 54321, val1 = 100000, val2 = 10;
    printf("%d\n", val % val1);
    val1 = val1 / val2;
    printf("%d\n", val % val1);
    val1 = val1 / val2;
    printf("%d\n", val % val1);
    val1 = val1 / val2;
    printf("%d\n", val % val1);
    val1 = val1 / val2;
    printf("%d\n", val % val1);
    return 0;
}





