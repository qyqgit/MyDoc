/*
 * 变量练习
 * */
#include <stdio.h>
int main() {
    int val = 54321, val1 = 10;
    printf("%d\n", val);
    val = val / val1;
    printf("%d\n", val);
    val = val / val1;
    printf("%d\n", val);
    val = val / val1;
    printf("%d\n", val);
    val = val / val1;
    printf("%d\n", val);
    return 0;
}
