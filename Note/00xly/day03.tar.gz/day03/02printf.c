/*
 * printf标准函数演示
 * */
#include <stdio.h>
int main() {
    printf("1\n");
    printf("%d\n", 1);
    printf("%d\n", 8 - 7);
    printf("a%db%dc\n", 1, 2);
    return 0;
}






