/*
 * 变量演示
 * */
#include <stdio.h>
int main() {
    int val = 1;
    printf("%d ", val);
    val++;
    printf("%d ", val);
    val++;
    printf("%d ", val);
    val++;
    printf("%d ", val);
    val++;
    printf("%d\n", val);
    return 0;
}





