/*
 * scanf标准函数演示
 * */
#include <stdio.h>
int main() {
    int val = 0, val1 = 0;
    printf("请输入两个整数：");
    scanf("%d%d", &val, &val1);
    printf("val是%d\n", val);
    printf("val1是%d\n", val1);
    return 0;
}





