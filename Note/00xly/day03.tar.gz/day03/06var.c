/*
 * 变量练习
 * */
#include <stdio.h>
int main() {
    int val = 1, val1 = 10;
    printf("%d X %d = %d\n", val, val1 - val, val * (val1 - val));
    val++;
    printf("%d X %d = %d\n", val, val1 - val, val * (val1 - val));
    val++;
    printf("%d X %d = %d\n", val, val1 - val, val * (val1 - val));
    val++;
    printf("%d X %d = %d\n", val, val1 - val, val * (val1 - val));
    val++;
    printf("%d X %d = %d\n", val, val1 - val, val * (val1 - val));
    return 0;
}




