/*
 * 求和练习
 * */
#include <stdio.h>
int main() {
    int val = 0, val1 = 0;
    printf("请输入两个数字：");
    scanf("%d%d", &val, &val1);
    printf("求和结果是%d\n", val + val1);
    return 0;
}
