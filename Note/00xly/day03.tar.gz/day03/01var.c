/*
 * 变量演示
 * */
#include <stdio.h>
int main() {
    int val;    //变量声明语句
    val = 10;   //赋值语句
    val = 8 + 6;
    val + 3;
    val = val;
    return 0;
}




