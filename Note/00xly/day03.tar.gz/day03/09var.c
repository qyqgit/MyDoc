/*
 * 变量练习
 * */
#include <stdio.h>
int main() {
    int sum = 0, val = 1;
    sum = sum + val;
    val++;
    sum = sum + val;
    val++;
    sum = sum + val;
    val++;
    sum = sum + val;
    val++;
    sum = sum + val;
    printf("求和结果是%d\n", sum);
    return 0;
}





