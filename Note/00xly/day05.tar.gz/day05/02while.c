/*
 * while循环练习
 * */
#include <stdio.h>
int main() {
    int val = 0, sum = 0;
    while (val >= 0) {
        printf("请输入一个数字：");
        scanf("%d", &val);
        if (val >= 0) {
            sum = sum + val;
        }
    }
    printf("求和结果是%d\n", sum);
    return 0;
}





