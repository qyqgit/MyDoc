/*
 * while循环演示
 * */
#include <stdio.h>
int main() {
    int val1 = 0, val2 = 0, tmp = 0;
    printf("请输入两个数字：");
    scanf("%d%d", &val1, &val2);
    while (val1 % val2) {
        tmp = val1 % val2;
        val1 = val2;
        val2 = tmp;
    }
    printf("最大公约数是%d\n", val2);
    return 0;
}





