/*
 * 费氏数列练习
 * */
#include <stdio.h>
int main() {
    int arr[20] = {1, 1};
    int num = 0;
    for (num = 2;num <= 19;num++) {
        arr[num] = arr[num - 2] + arr[num - 1];
    }
    for (num = 0;num <= 19;num++) {
        printf("%d ", arr[num]);
    }
    printf("\n");
    return 0;
}





