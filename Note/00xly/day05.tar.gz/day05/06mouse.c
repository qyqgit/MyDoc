/*
 * 打地鼠练习
 * */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
    int mouse_row = 0, mouse_col = 0;  //记录老鼠的位置
    int ham_row = 0, ham_col = 0;  //记录锤子的位置
    int missed = 0/*记录错过的次数*/, hits = 0/*打中的次数*/;
    int times = 0;  //游戏总次数
    int num = 0, row = 0, col = 0;
    srand(time(0));
    printf("请输入游戏次数：");
    scanf("%d", &times);
    printf("***\n***\n***\n");
    for (num = 1;num <= times;num++) {
        printf("请选择一个位置：");
        scanf("%d%d", &ham_row, &ham_col);
        mouse_row = rand() % 3 + 1;
        mouse_col = rand() % 3 + 1;
        for (row = 1;row <= 3;row++) {    //循环变量代表行号
            for (col = 1;col <= 3;col++) {  //循环变量代表列号
                if (row == ham_row && col == ham_col) {
                    printf("O");
                }
                else if (row == mouse_row && col == mouse_col) {
                    printf("X");
                }
                else {
                    printf("*");
                }
            }
            printf("\n");
        }
        if (ham_row == mouse_row && ham_col == mouse_col) {
            hits++;
        }
        else {
            missed++;
        }
        printf("打中%d次，错过%d次\n", hits, missed);
    }
    return 0;
}







